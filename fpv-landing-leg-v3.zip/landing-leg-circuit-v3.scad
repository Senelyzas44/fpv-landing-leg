// Measurements in mm. The arm underside is at z = 0.
part = "leg"; // [leg,gauge,shoe]
shoe_clearance = 0.35;
arm_width = 19;
total_fit_clearance = 0;
saddle_length = 48;
cheek_height = 6;
cheek_wall = 3.5;
tie_pitch = 30;
tie_slot_width = 8.2;
tie_slot_height = 2.4;
drop = 150;
splay = 10;
circuit_texture = true;

$fn = 32;
channel = arm_width + total_fit_clearance;
saddle_width = channel + 2 * cheek_wall;
base_depth = 9;
foot_x = drop * tan(splay);

module saddle() {
    difference() {
        union() {
            translate([-saddle_length/2, -saddle_width/2, -base_depth])
                cube([saddle_length, saddle_width, base_depth]);
            for (side = [-1, 1])
                translate([-saddle_length/2, side*(channel+cheek_wall)/2-cheek_wall/2, -0.2])
                    cube([saddle_length, cheek_wall, cheek_height+0.2]);
        }
        for (x = [-tie_pitch/2, tie_pitch/2])
            translate([x, 0, -base_depth/2])
                cube([tie_slot_width, saddle_width+2, tie_slot_height], center=true);
    }
}

// Thin rounded horizontal sections define the taper and broad root.
module section(x, z, length, width, radius) {
    translate([x, 0, z])
        linear_extrude(height=1)
            offset(r=radius)
                square([length-2*radius, width-2*radius], center=true);
}

module heel(clearance=0) {
    hull() {
        section(foot_x-1, -142, 18+2*clearance, saddle_width+2*clearance, 3);
        section(foot_x, -145-clearance, 22+2*clearance, saddle_width+2*clearance, 3);
    }
}
module shoe() {
    difference() {
        hull() {
            section(foot_x, -150, 27, saddle_width+4.8, 4);
            section(foot_x-1, -139, 24.5, saddle_width+4.8, 4);
        }
        heel(shoe_clearance);
        hull() {
            section(foot_x-1, -142, 18+2*shoe_clearance, saddle_width+2*shoe_clearance, 3);
            section(foot_x-1.6, -137, 19+2*shoe_clearance, saddle_width+2*shoe_clearance, 3);
        }
    }
}
// [center X, depth, section length] for the tapered web.
stations = [[0,14,43], [7,40,23], [16,90,19], [foot_x-1,142,18]];
rounding = 3;

module strut() {
    hull() {
        section(0, -14, 43, saddle_width, 3);
        section(0, -8.5, 43, saddle_width, 3);
    }
    for (i = [0:len(stations)-2])
        hull()
            for (j = [i,i+1])
                section(stations[j][0], -stations[j][1], stations[j][2],
                        saddle_width, rounding);
    heel();
}

// Each trace is on the positive-Y face. Coordinates are [arm axis, drop].
relief_height = 0.40;
trace_width = 1.05;
// Planar half-width is the rounded section half-width minus its corner radius.
function face_limits(d, i=0) =
    let(a=stations[i], b=stations[i+1])
    d > b[1] && i < len(stations)-2 ? face_limits(d, i+1) :
    let(t=min(1,max(0,(d-a[1])/(b[1]-a[1]))))
    [a[0]+(b[0]-a[0])*t, (a[2]+(b[2]-a[2])*t)/2-rounding];
function inset_x(point) =
    let(face=face_limits(-point[1]), run=face[1]-2.6)
    min(face[0]+run, max(face[0]-run, point[0]));
module copper_point(point, diameter) {
    translate([inset_x(point), saddle_width/2+relief_height, point[1]])
        rotate([90,0,0])
            cylinder(h=relief_height+0.15, d=diameter);
}
module trace(points) {
    for (i = [0:len(points)-2])
        hull() {
            copper_point(points[i], trace_width);
            copper_point(points[i+1], trace_width);
        }
}
module texture() {
    // Main route runs from the saddle to just above the TPU overlap.
    trace([[-10,-2],[-6,-6],[-6,-13],[0,-19],[0,-28],[5,-33],
           [5,-46],[9,-50],[9,-59],[12,-62],[12,-69],[15,-72],
           [15,-84],[18,-87],[18,-101],[22,-105],[22,-121],
           [25,-124],[25,-135]]);
    // Branches rejoin the main route to form a circuit-board layout.
    trace([[-6,-13],[9,-13],[13,-17],[13,-29],[9,-33],[5,-33]]);
    trace([[0,-19],[-9,-19],[-13,-23],[-13,-28],[-8,-33],[5,-33]]);
    trace([[5,-46],[14,-46],[17,-49],[17,-55],[13,-59],[9,-59]]);
    trace([[12,-69],[7,-69],[5,-72],[7,-75],[5,-78],[8,-81],
           [7,-84],[10,-87],[18,-87]]);
    trace([[18,-87],[24,-87],[26,-89],[26,-97],[22,-101],[18,-101]]);
    trace([[22,-105],[16,-105],[14,-107],[14,-116],[19,-121],[22,-121]]);
    trace([[25,-124],[30,-124],[32,-126],[32,-131],[28,-135],[25,-135]]);
    for (p = [[-10,-2],[-13,-28],[13,-17],[17,-55],[15,-72],
              [10,-87],[26,-97],[14,-107],[32,-131],[25,-135]])
        copper_point(p, 2.5);
}

if (part == "shoe") {
    translate([-foot_x,0,150]) shoe();
} else {
    // Lay the leg on its side so the strut runs in the print plane.
    translate([saddle_length/2,0,saddle_width/2])
        rotate([90,0,0])
            if (part == "gauge") {
                saddle();
            } else {
                union() {
                    saddle();
                    strut();
                    if (circuit_texture) texture();
                }
            }
}
