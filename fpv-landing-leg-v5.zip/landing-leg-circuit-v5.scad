// Measurements in mm. The arm underside is at z = 0.
part = "leg"; // [leg,gauge,shoe]
shoe_clearance = 0.35;
arm_width = 19;
total_fit_clearance = 0;
saddle_length = 48;
cheek_height = 6;
cheek_wall = 3.5;
tie_pitch = 30;
tie_slot_width = 8.2;
tie_slot_height = 2.4;
drop = 150;
splay = 10;
circuit_texture = true;

$fn = 32;
channel = arm_width + total_fit_clearance;
saddle_width = channel + 2 * cheek_wall;
base_depth = 9;
foot_x = drop * tan(splay);

module saddle() {
    difference() {
        union() {
            translate([-saddle_length/2, -saddle_width/2, -base_depth])
                cube([saddle_length, saddle_width, base_depth]);
            for (side = [-1, 1])
                translate([-saddle_length/2, side*(channel+cheek_wall)/2-cheek_wall/2, -0.2])
                    cube([saddle_length, cheek_wall, cheek_height+0.2]);
        }
        for (x = [-tie_pitch/2, tie_pitch/2])
            translate([x, 0, -base_depth/2])
                cube([tie_slot_width, saddle_width+2, tie_slot_height], center=true);
    }
}

// Thin rounded horizontal sections define the taper and broad root.
module section(x, z, length, width, radius) {
    translate([x, 0, z])
        linear_extrude(height=1)
            offset(r=radius)
                square([length-2*radius, width-2*radius], center=true);
}

module heel(clearance=0) {
    hull() {
        section(foot_x-1, -142, 18+2*clearance, saddle_width+2*clearance, 3);
        section(foot_x, -145-clearance, 22+2*clearance, saddle_width+2*clearance, 3);
    }
}
module shoe() {
    difference() {
        hull() {
            section(foot_x, -150, 27, saddle_width+4.8, 4);
            section(foot_x-1, -139, 24.5, saddle_width+4.8, 4);
        }
        heel(shoe_clearance);
        hull() {
            section(foot_x-1, -142, 18+2*shoe_clearance, saddle_width+2*shoe_clearance, 3);
            section(foot_x-1.6, -137, 19+2*shoe_clearance, saddle_width+2*shoe_clearance, 3);
        }
    }
}
// [center X, depth, section length] for the tapered web.
stations = [[0,14,43], [7,40,23], [16,90,19], [foot_x-1,142,18]];
rounding = 3;

module strut() {
    hull() {
        section(0, -14, 43, saddle_width, 3);
        section(0, -8.5, 43, saddle_width, 3);
    }
    for (i = [0:len(stations)-2])
        hull()
            for (j = [i,i+1])
                section(stations[j][0], -stations[j][1], stations[j][2],
                        saddle_width, rounding);
    heel();
}

// Each trace is on the positive-Y face. Coordinates are [arm axis, drop].
engraving_depth = 0.40;
cut_overlap = 0.05;
trace_width = 1.05;
// Planar half-width is the rounded section half-width minus its corner radius.
function face_limits(d, i=0) =
    let(a=stations[i], b=stations[i+1])
    d > b[1] && i < len(stations)-2 ? face_limits(d, i+1) :
    let(t=min(1,max(0,(d-a[1])/(b[1]-a[1]))))
    [a[0]+(b[0]-a[0])*t, (a[2]+(b[2]-a[2])*t)/2-rounding];
// Coordinates are [offset from the face centerline, distance below the arm].
function on_face(p) = [face_limits(p[1])[0] + p[0], -p[1]];

module stroke(points, width=0.95) {
    for (i = [0:len(points)-2])
        hull()
            for (j = [i,i+1])
                translate(on_face(points[j])) circle(d=width);
}

module node(depth, rx, ry) {
    stroke([for (a=[0:15:360]) [rx*cos(a),depth+ry*sin(a)]]);
    stroke([[0,depth-ry],[0,depth],[0,depth+ry]]);
    translate(on_face([0,depth])) circle(d=1.8);
}

module texture() {
    translate([0,saddle_width/2+cut_overlap,0])
        rotate([90,0,0])
            linear_extrude(height=engraving_depth+cut_overlap)
                union() {
                    // Main spine and the concentric saddle glyph.
                    stroke([[0,2],[0,14],[0,40],[0,90],[0,135]]);
                    node(20,6.4,9);
                    node(20,3.2,5);
                    node(53,4.4,7);
                    node(91,3.1,7);
                    node(124,2.8,6);
                    // Paired traces form nested loops between successive nodes.
                    for (side=[-1,1]) {
                        stroke([[0,7],[side*5,7],[side*9,12],[side*10,18],
                                [side*9,26],[side*6,32],[side*4,40],[0,46]]);
                        stroke([[0,60],[side*3,63],[side*5,69],[side*5,75],
                                [side*4,79],[0,84]]);
                        stroke([[0,98],[side*2.5,101],[side*4,107],
                                [side*3.7,112],[0,118]]);
                        // Split terminals and short branching marks.
                        stroke([[side*5,69],[side*3,69],[side*2,72]]);
                        stroke([[side*5,75],[side*3,76],[side*2,79]]);
                        stroke([[0,132],[side*2.4,135],[side*2.5,137]]);
                        translate(on_face([side*2.5,137])) circle(d=1.6);
                    }
                }
}

if (part == "shoe") {
    translate([-foot_x,0,150]) shoe();
} else {
    // Lay the leg on its side so the strut runs in the print plane.
    translate([saddle_length/2,0,saddle_width/2])
        rotate([90,0,0])
            if (part == "gauge") {
                saddle();
            } else {
                difference() {
                    union() {
                        saddle();
                        strut();
                    }
                    if (circuit_texture) texture();
                }
            }
}
